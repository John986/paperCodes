function[measures]=fun_of_SBLR_alpha(features, labels, numfolds, options)

[X, Y]=Cross_validation_2(features,labels, numfolds);
[~, m]=size(labels);
for i=1:numfolds
    disp('cross validation fold')
    disp(i)
   Xtrain=X{i}.train;
   Ytrain=Y{i}.train;
   
   Xtest=X{i}.test;
   Ytest=Y{i}.test;
   [Beta, mu, sigma]=SBLR_train_alpha(Xtrain, Ytrain, options);   
   measures(i)=SBLR_test_alpha(Xtrain, Ytrain, Xtest, Ytest, Beta, options, mu, sigma);

end

end