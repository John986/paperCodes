% run cross validation
clear;clc
% addpath('C:\Users\zcm\OneDrive\similarity-based multilabel classification\SML_my')
addpath('C:\Users\zcm\OneDrive\similarity-based multilabel classification\SML')
% addpath('C:\Users\zcm\OneDrive\similarity-based multilabel classification\SBLR_ML_alpha')



load('MB_yeast.mat')


X=features;
Y=MB_labels;

%%
% map matrix row minimum and maximum values to [-1 1].




% X = zscore(X);



% [n, d]=size(X);
% for ni=1:n 
%     X(ni, :)=X(ni, :)/norm(X(ni, :));    
%   
% end


Xnorm=mapminmax(X');
X=Xnorm';


%%


 numfolds=10;
 


options.KernelType='Gaussian';
% options.KernelType='Polynomial';

% options.d=2;
options.K=10;



  
% set=[10^1, 10^2, 10^3, 10^4, 10^5];

% set1=0.55;
set1=[10^3, 10^2, 10^1, 1, 10^-1, 10^-2, 10^-3, 10^-4, 10^-5];
set2=[10^5, 10^4, 10^3, 10^2, 10^1, 1, 10^-1, 10^-2, 10^-3, 10^-4, 10^-5];
%   set2=10^-5.*[5:-1:1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2];
%   set1=0.1*[0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 2, 3, 4, 5];
% set1=0.45;
% set2=5*10^-4;

lo=100000;
for i1=1:length(set1)
    for i2=1%:length(set2)
        options.t=set1(i1);
%         options.d=set1(i1);
        lambda=set2(i2);
%             measures=fun_of_SBLR_alpha(X, Y, numfolds,options);
%             measures=fun_of_mlknn(X, Y, numfolds);
%             measures=fun_of_SML(X, Y, numfolds,options);
            measures=fun_of_SparseSBLR(X, Y, numfolds, options, lambda);
%             measures=fun_of_IBLR(X, Y, numfolds, options);
            mm=0;
            for j=1:numfolds
                mm=mm+ measures(j).HammingLoss;
            end

            if mm < lo
               optimal.t=options.t;
%                optimal.d=options.d;
               optimal.lambda=lambda;
               optimal.measures=measures;
               lo=mm;
            end
    end

end

 optimal

 
 load chirp
 sound(y,Fs)

 