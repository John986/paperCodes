function[measures]=fun_of_SML(features, labels, numfolds, options)

[X, Y]=Cross_validation_1(features,labels, numfolds);
[~, m]=size(labels);
for i=1:numfolds
    disp('cross validation fold')
    disp(i)
   Xtrain=X{i}.train;
   Ytrain=Y{i}.train;
   
   Xtest=X{i}.test;
   Ytest=Y{i}.test;
   [w]=SML_train(Xtrain, Ytrain, options);   
   measures(i)=SML_test(Xtrain, Ytrain, Xtest, Ytest, w, options);

end

end