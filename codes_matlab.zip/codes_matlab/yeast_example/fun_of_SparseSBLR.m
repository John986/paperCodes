function[measures]=fun_of_SparseSBLR(features, labels, numfolds, options, lambda)

[X, Y]=Cross_validation(features,labels, numfolds);
[~, m]=size(labels);
for i=1:numfolds
    disp('cross validation fold')
    disp(i)
   Xtrain=X{i}.train;
   Ytrain=Y{i}.train;
   
   Xtest=X{i}.test;
   Ytest=Y{i}.test;
   [Beta, mu, sigma]=SparseSBLR_train(Xtrain, Ytrain, options, lambda);   
   measures(i)=SparseSBLR_test(Xtrain, Ytrain, Xtest, Ytest, Beta, options, mu, sigma);

end

end