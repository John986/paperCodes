% count_result

a=optimal.measures;
res=zeros(10, 5);
for i=1:10
    res(i, 1)=a(1, i).HammingLoss;
    res(i, 2)=a(1, i).RankingLoss;
    res(i, 3)=a(1, i).OneError;
    res(i, 4)=a(1, i).Coverage;
    res(i, 5)=a(1, i).Average_Precision;   
    
end

disp('hamming    ranking   oneerror   coverage    precision')
disp(mean(res))
% mean(res)