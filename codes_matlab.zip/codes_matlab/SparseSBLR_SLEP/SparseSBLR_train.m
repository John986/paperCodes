function[Beta, mu, sigma]=SparseSBLR_train(Xtrain, Ytrain, options, lambda)
%   Xtrain        : A nxd array, the ith instance of training instance is stored in train_data(i,:)
%   Ytrain        : A nxm array, if the ith training instance belongs to the jth
%                   class, then train_target(i,j) equals +1, otherwise train_target(j,i) equals 0
%   options       : Struct value in Matlab. The fields in options that can
%                   be set: 
%           KernelType  -  Choices are:
%               'Gaussian'      - e^{-(|x-y|^2)/2t^2}
%               'Polynomial'    - (x'*y)^d
%               'PolyPlus'      - (x'*y+1)^d
%               'Linear'        -  x'*y
%               t       -  parameter for Gaussian
%               d       -  parameter for Poly
%

K = constructKernel(Xtrain,[],options);
[n, m]=size(Ytrain);

Z=zeros(n, m);
for k=1:n
%    Z(k, :)=K(:, k)'*Ytrain./sum(Ytrain);  
   Z(k, :)=K(:, k)'*Ytrain;  
end

%��һ����Ч��������
% Z = 1./(1+exp(-Z));
% Z=[ones(n, 1), Z];

 [Z,mu,sigma] = zscore(Z);


% train the classifier hj for label j
%----------------------- Set optional items -----------------------
opts=[];
% rho=0.1; 
rho=lambda;
% Starting point
opts.init=2;        % starting from a zero point

% Termination 
opts.tFlag=5;       % run .maxIter iterations
opts.maxIter=1500;    % maximum number of iterations

% Normalization
opts.nFlag=0;       % without normalization

% Regularization
opts.rFlag=0;       % the input parameter 'rho' is a ratio in (0, 1)
opts.rsL2=0;     % the squared two norm term

% Group Property
opts.sWeight=[1,1]; % set the weight for positive and negative samples
opts.mFlag=0;       % treating it as compositive function 
opts.lFlag=0;       % Nemirovski's line search


Ytrain=Ytrain.*2-1;

Beta=zeros(m+1, m);
for i=1:m
    disp('label')
    disp(i);
    pos_w=sum(Ytrain(:, i)+1)/(2*n);
    opts.sWeight=[pos_w, 1-pos_w];
%     Beta(:, i)=Sparseclassifierhj(Z, Ytrain(:, i), lambda);
    if pos_w~=0
        [x, c, funVal, ValueL]=LogisticR(Z, Ytrain(:, i), rho, opts);
        Beta(:, i)=[c;x];   
    end


    
end
end