function[measures]=SML_test(Xtrain, Ytrain, Xtest, Ytest, w, options)
%   Xtrain, Xtest : A nxd array, the ith instance of training instance is stored in train_data(i,:)
%   Ytrain, Ytest : A nxm array, if the ith training instance belongs to the jth
%                   class, then train_target(i,j) equals +1, otherwise train_target(j,i) equals 0
%   options       : Struct value in Matlab. The fields in options that can
%                   be set: 
%           KernelType  -  Choices are:
%               'Gaussian'      - e^{-(|x-y|^2)/2t^2}
%               'Polynomial'    - (x'*y)^d
%               'PolyPlus'      - (x'*y+1)^d
%               'Linear'        -  x'*y
%               t       -  parameter for Gaussian
%               d       -  parameter for Poly

% measures:      :Struct value in Matlab. The fields in measures that can be
%                 set

%           HammingLoss      - The hamming loss on testing data
%           RankingLoss      - The ranking loss on testing data
%           OneError         - The one-error on testing data as
%           Coverage         - The coverage on testing data as
%           Average_Precision- The average precision on testing data
%           Outputs          - A QxM2 array, the probability of the ith testing instance belonging to the jCth class is stored in Outputs(j,i)
%           Pre_Labels       - A QxM2 array, if the ith testing instance belongs to the jth class, then Pre_Labels(j,i) is +1, otherwise Pre_Labels(j,i) is -1



[ntest, ~]=size(Xtest);
[~, m]=size(Ytrain);
Outputs=zeros(ntest, m);
Threshold=zeros(ntest, 1);
for k=1:ntest
   Kxnew = constructKernel(Xtest(k, :), Xtrain,options);
   
%    znew=Kxnew*Ytrain./sum(Ytrain);
   znew=Kxnew*Ytrain;
%    znew=1./(1+exp(-znew));
%    znew=(znew-mu)./sigma;
   
   
   Threshold(k)=w'*[1, znew]';
   Outputs(k, :)=znew;   
   
end




Outputs=Outputs';
Ytest=Ytest'*2-1; % convert (0, 1) value to (-1, 1)




%Evaluation
Pre_Labels=zeros(m,ntest);
for i=1:ntest
    for j=1:m
        
        if(Outputs(j,i)>=Threshold(i))
            Pre_Labels(j,i)=1;
        else
            Pre_Labels(j,i)=-1;
        end
    end
end
    measures.HammingLoss=Hamming_loss(Pre_Labels,Ytest);    
    measures.RankingLoss=Ranking_loss(Outputs,Ytest);
    measures.OneError=One_error(Outputs,Ytest);
    measures.Coverage=coverage(Outputs,Ytest);
    measures.Average_Precision=Average_precision(Outputs,Ytest);


end