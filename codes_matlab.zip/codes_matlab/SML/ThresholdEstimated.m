function[w]=ThresholdEstimated(Xtrain, Ytrain, options)

K = constructKernel(Xtrain,[],options);
[n, m]=size(Ytrain);

% Z=K*Ytrain./sum(Ytrain);
Z=K*Ytrain;
% Z=1./(1+exp(-Z));

% [Z, mu, sigma]=zscore(Z);

s=zeros(n, 1);
for i=1:n

    z=Z(i, :);
    y=Ytrain(i, :);
    posInd=find(y>0);
    negInd=find(y<1);
    
    Une=max(z(negInd));
    Lpo=min(z(posInd));

    
    if isempty(Une)
       errset1=[];
    else
       errset1=find(z<=Une);  
    end
    
    if isempty(Lpo)
       errset2=[];
    else
       errset2=find(z>=Lpo);
    end   
  

    InIndex=intersect(errset1, errset2);  
    
    lineS=Lpo:(Une-Lpo)/(2*m):Une;
    op_errC=length(z);
    
    if isempty(InIndex)
        s(i)=(Une+Lpo)/2;
    else 
       for serL=1:length(lineS)
            errset1=find(z(posInd)<=lineS(serL));    
            errset2=find(z(negInd)>=lineS(serL));
            errC=length(errset1)+length(errset2);
            if errC<op_errC
                s(i)=lineS(serL);
                op_errC=errC;
            end        
       end
        
        
%         s(i)=median(z(InIndex));
    end
    

    
end
    
    Z=[ones(n, 1), Z];
    w=pinv(Z'*Z)*(Z'*s);
%     w=(Z'*Z+10^-1*eye(m+1))\(Z'*s);





end