function beta=classifierhj_alpha(Z, y)

[~, q]=size(Z);
betaI=rand(q, 1);

Data.Z=Z;
Data.y=y;

out=lbfgs(@(x) obj(x, Data), betaI, 'RelFuncTol', 1e-16, 'StopTol', 1e-8, ...
    'MaxFuncEvals', 100, 'Display', 'final');

beta=out.X;



end

function[f, g]=obj(x, Data)
Z=Data.Z;
y=Data.y;

%%
n=length(y);
f=0;
for k=1:n
    z=Z(k, :)';
    tempE=x'*z;
    if tempE >500
        f=f-y(k)*tempE+tempE;
    else
        f=f - y(k)*x'*z+log(1+exp(x'*z));
    end
end

%%


g=0;
for k=1:n
    z=Z(k, :)';
    tempE=x'*z;
    if tempE >500
        p=1;
    else
        p=exp(x'*z)/(1+exp(x'*z));
    end
    g=g - z*(y(k)-p);
    
end

end

