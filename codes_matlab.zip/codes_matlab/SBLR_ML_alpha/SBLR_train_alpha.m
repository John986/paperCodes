function[Beta, mu, sigma]=SBLR_train_alpha(Xtrain, Ytrain, options)
%   Xtrain        : A nxd array, the ith instance of training instance is stored in train_data(i,:)
%   Ytrain        : A nxm array, if the ith training instance belongs to the jth
%                   class, then train_target(i,j) equals +1, otherwise train_target(j,i) equals 0
%   options       : Struct value in Matlab. The fields in options that can
%                   be set: 
%           KernelType  -  Choices are:
%               'Gaussian'      - e^{-(|x-y|^2)/2t^2}
%               'Polynomial'    - (x'*y)^d
%               'PolyPlus'      - (x'*y+1)^d
%               'Linear'        -  x'*y
%               t       -  parameter for Gaussian
%               d       -  parameter for Poly
%

K = constructKernel(Xtrain,[],options);
[n, m]=size(Ytrain);

Z=zeros(n, m);
for k=1:n
   Z(k, :)=K(:, k)'*Ytrain;  
end
[Z,mu,sigma] = zscore(Z);

Z=[ones(n, 1), Z];

% train the classifier hj for label j
%_abandoned
Beta=zeros(m+1, m);
for i=1:m
    disp('label')
    disp(i);
    Beta(:, i)=classifierhj_alpha(Z, Ytrain(:, i));
    
end
end