function beta=classifierhj_abandoned(Z, y)

[~, q]=size(Z);

r=0.8;
a=0.5;
t=0;

betaI=rand(q, 1);
theta=betaI;

Flag=1;
MaxIter=1;

beta=betaI;

while Flag==1&& MaxIter<100
   sFlag=1;
   s=1;
   gell=gobj(Z, y, beta);
   ell=obj(Z, y, beta);
   while sFlag==1
       s=r*s;       
       TerC=obj(Z, y, beta-s*gell)<=ell-a*s*(gell'*gell);
       if TerC
           sFlag=0;
       end
   end
   beta=theta-s*gell;
   theta=beta+t/(t+3)*(beta-betaI);   
   if norm(beta-betaI, 2)/norm(betaI) > 10^-3
%        disp('MaxIter')
       MaxIter=MaxIter+1;
%        disp('Iteration size')
%        norm(beta-betaI, 2)/norm(betaI);
       betaI=beta;
       t=t+1;
   else
       Flag=0;
   end
       
   
   
end  
   
end

function gell=gobj(Z, y, beta)

n=length(y);
gell=0;
for k=1:n
    z=Z(k, :)';
    tempE=beta'*z;
    if tempE >500
        p=1;
    else
        p=exp(beta'*z)/(1+exp(beta'*z));
    end
    gell=gell - z*(y(k)-p);
    
end
end


function ell=obj(Z, y, beta)
n=length(y);
ell=0;
for k=1:n
    z=Z(k, :)';
    tempE=beta'*z;
    if tempE >500
        ell=ell-y(k)*tempE+tempE;
    else
        ell=ell - y(k)*beta'*z+log(1+exp(beta'*z));
    end
end
end